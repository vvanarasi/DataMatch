import pandas as pd
import os
import glob
from pandas import ExcelFile
from pandas import ExcelWriter
import time

def match():
    allRefData = pd.DataFrame()
    allSrcData = pd.DataFrame()
    dfRes = pd.DataFrame()

    for subdir, dirs, files in os.walk("."):
        for file in files:
            fullfilepath = os.path.join(subdir,file)
            #print(fullfilepath)
            if 'Reference' in fullfilepath and fullfilepath.endswith('.xlsx'):
                dfRef = pd.read_excel(fullfilepath,sheetname='Sheet1',header=None)
                allRefData = allRefData.append(dfRef, ignore_index=True)
            elif 'Source' in fullfilepath and fullfilepath.endswith('.xlsx'):
                dfSrc = pd.read_excel(fullfilepath, sheetname='Sheet1')
                allSrcData = allSrcData.append(dfSrc, ignore_index=True)

    #print(allRefData)
    #print(allSrcData)

    for phn in allSrcData['Phone']:
        #print(phn)
        for i, row in allRefData.iterrows():
            for j, col in row.iteritems():
                if str(col) in str(phn):
                    #print(row)
                    dfRes = dfRes.append(row)

    #print(dfRes)
    outputFile = 'Results_' + time.strftime("%Y%m%d-%H%M%S") + '.xlsx'
    writer = pd.ExcelWriter(outputFile, engine='xlsxwriter')
    dfRes.to_excel(writer, sheet_name='Results', index=False)


if __name__ == "__main__":
    match()
